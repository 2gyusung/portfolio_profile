var typed = new Typed(".auto-type", {
  strings : ["Passionate", "Gradual", "Growing"],
  typeSpeed : 150,
  backSpeed : 150,
  looped : true
})
